module.exports = {
  businessLocations: [],
  num: 10,
};